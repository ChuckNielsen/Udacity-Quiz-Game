package com.android.example.quiz;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.example.quiz.R;

public class MainActivity extends AppCompatActivity {

    private int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void submit(View view) {

        RadioButton q1 = findViewById(R.id.q11);
        if (q1.isChecked())
            score++;

        EditText q2 = findViewById( R.id.q2);
        if (q2.getText().toString().trim().equals("18"))
            score++;

        CheckBox q21 = findViewById(R.id.q21);
        CheckBox q22 = findViewById(R.id.q22);
        CheckBox q23 = findViewById(R.id.q23);
        CheckBox q24 = findViewById(R.id.q24);
        if (q21.isChecked()&&q22.isChecked()&&!q23.isChecked()&&!q24.isChecked())
            score++;

        RadioButton q4 = findViewById(R.id.q42);
        if (q4.isChecked())
            score++;

        EditText q5 = findViewById(R.id.q5);
        if (q5.getText().toString().trim().equals("5"))
            score++;

        if (score == 5) {
            Toast.makeText(this, "Perfect! 100% All answers are correct!!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Your a little off, your score is: " + score, Toast.LENGTH_SHORT).show();
        }

        score = 0;
    }

}
